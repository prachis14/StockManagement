package com.example.stockmanagement;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.*;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener {

Spinner spname;
TextView tv_price,total;
EditText et_qty;
Button ok;

String products[]={"cheese","Butter","Mayonise","Paneer","ButterMilk"};
double product_price[]={3.7,2.7,2.3,2,0.8};
int product_qty[]={15,20,12,22,17};
    public static double subtotal = 0.0;
    public static double total1 = 0.0;
    public static double grandtotal1 = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spname=findViewById(R.id.sp_name);
        tv_price=findViewById(R.id.tv_price);
        total=findViewById(R.id.tv_total);
        et_qty=findViewById(R.id.et_qty);
        ok=findViewById(R.id.btn);
        ok.setOnClickListener(this);

        ArrayAdapter adapter = new ArrayAdapter( this, android.R.layout.simple_spinner_dropdown_item,products);
        spname.setAdapter(adapter);
        spname.setOnItemSelectedListener(this);

    }
    String selectedName;

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
    tv_price.setText(String.valueOf(product_price[position]));
    selectedName = products[position];
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        tv_price.setText(String.valueOf(product_price[0]));
    }

    @Override
    public void onClick(View v) {
        int selectedProductQuantity = 0;

        if (et_qty.getText().toString().isEmpty())
        {
            Toast.makeText(getBaseContext(), " please enter required quantity", Toast.LENGTH_LONG).show();
        }
        else
        {
            int enteredQuantity = Integer.parseInt(et_qty.getText().toString());
            for (int i = 0; i < products.length; i++)
            {
                if (products[i].equalsIgnoreCase(selectedName))
                {
                    selectedProductQuantity = product_qty[i];
                }
            }
            if (selectedProductQuantity < enteredQuantity)
            {
                Toast.makeText(getBaseContext(), "No sufficient quantity", Toast.LENGTH_LONG).show();
            }
            else if(enteredQuantity<10)
            {
                int quantity = Integer.parseInt(et_qty.getText().toString());
                double drinkPrice = Double.parseDouble(tv_price.getText().toString());
                subtotal += drinkPrice * quantity;
                total.setText(String.format("%.2f", total));
            }
            else
            {
                int quantity = Integer.parseInt(et_qty.getText().toString());
                double drinkPrice = Double.parseDouble(tv_price.getText().toString());
                subtotal += drinkPrice * quantity ;
                total1 = subtotal * 0.05;
                grandtotal1 = subtotal-total1;
                total.setText(String.format("%.2f", grandtotal1));
            }
        }
    }
}